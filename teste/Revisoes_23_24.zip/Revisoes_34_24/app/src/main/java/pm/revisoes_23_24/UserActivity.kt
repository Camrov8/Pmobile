package pm.revisoes_23_24

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import pm.revisoes_23_24.databinding.ActivityUserBinding

class UserActivity : AppCompatActivity() {

    private val binding by lazy {
        ActivityUserBinding.inflate(layoutInflater)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        intent.extras.let {
            val user = intent.extras?.getString("username","")
            binding.textView.text = "Bem-vindo " + user
        }
    }

    fun lancarNotificacao(view: View) {
        val channelId = "ua_pm"
        val notificationId = 1
        val notificationManager = getSystemService(NotificationManager::class.java)

        // 0. Redirecionar + Envio de dados
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 1. Criar a notificação
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ua)
            .setContentTitle("Desenvolvido por:")
            .setContentText("João Pedro - 123456")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        // 2. Criar o canal
        val channel = NotificationChannel(
            channelId,
            "Prog. Mobile",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Teste 1"
        }
        notificationManager.createNotificationChannel(channel)

        // 3. Lançar a notificação
        notificationManager.notify(notificationId, notification)
    }
}